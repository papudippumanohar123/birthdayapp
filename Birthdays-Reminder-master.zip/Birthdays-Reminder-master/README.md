# Birthdays-Reminder
An app that reminds you of your friends' and family's birthdays. Thus you will never forget an important day anymore. Just give the app date and a name and we will remind you by notification at the right time to buy gifts or make surprise birthday parties to make them happy on their birthdays.
